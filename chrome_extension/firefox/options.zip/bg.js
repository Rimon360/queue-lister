// const backend_url = "http://localhost:8000"
const backend_url = "https://javiqueuelist.cloud/api"

browser.action.onClicked.addListener(() => {
  browser.tabs.create({ url: "options.html" })
})

let trackDebuggerAdded = []
browser.runtime.onMessage.addListener((m, s, sr) => {
  if (m.ref == "solveCap") {
    console.log(m.ref)
    let tabId = s.tab.id
    let { x, y } = m
    if (!trackDebuggerAdded.includes(tabId)) {
      browser.debugger.attach({ tabId }, "1.3", () => {
        trackDebuggerAdded.push(tabId)
        clickAt(tabId, x, y)
      })
    } else {
      clickAt(tabId, x, y)
    }

    function clickAt(tabId, x, y) {
      browser.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
        type: "mousePressed",
        x,
        y,
        button: "left",
        clickCount: 1,
      })
      browser.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
        type: "mouseReleased",
        x,
        y,
        button: "left",
        clickCount: 1,
      })
    }
    sr("true")
  } else if (m.ref == "sendToServer") {
    if (m.req_body && m.req_url) {
      fetch(backend_url + "/queue/add", {
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify({
          req_url: m.req_url,
          req_body: m.req_body,
        }),
        method: "POST",
      })
        .then((r) => r.json())
        .then((r) => {
          console.log(r)
        })
    }
    sr("sending...")
  }
})
