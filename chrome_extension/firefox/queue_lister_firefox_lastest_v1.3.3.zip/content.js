;(async () => {
  let countInterval = 0
  let countTotalTime = 0

  window.addEventListener("message", (message) => {
    if (message.data.req_url) {
      let data = message.data
      browser.runtime.sendMessage({ ref: "sendToServer", req_url: data.req_url, req_body: data.req_body, original_queue_url: data.original_queue_url }, handleCallback)
      browser.runtime.sendMessage({ ref: "r_skip" }, handleCallback)
    }
  })

  while (true) {
    countInterval++
    countTotalTime++
    if (ifCloudFlare()) {
      // && countInterval > 4
      countInterval = 0
      await solveCap()
    } else if (countTotalTime > 20) {
      // if 20 seconds has passed but no queue id fount then move to next one;
      browser.runtime.sendMessage({ ref: "r_skip" }, handleCallback)
      console.log("Trying to skipp..........")
      break
    }
    await wait(1)
  }

  console.log(",,,,,,,,,,,,queue id getter is running,,,,,,,,,,,,")
})()

function handleCallback() {
  if (browser.runtime.lastError) {
    console.log(browser.runtime.lastError.message)
  }
}
async function solveCap() {
  let capResInput = document.querySelector('input[name="cf-turnstile-response"]')
  if (capResInput?.value != "") return true // cap is solved automatically
  await new Promise((rs) => {
    let { x, y, width, height } = capResInput.parentElement.getBoundingClientRect()
    console.log(x, y)

    x = x + 25
    y = y + height / 2
    browser.runtime.sendMessage({ ref: "solveCap", x, y }, (res) => {
      rs(res)
    })
  })
  return true
}
function ifCloudFlare() {
  let cloudflareLink = document.querySelector('div[role="contentinfo"] a')?.href
  if (cloudflareLink && cloudflareLink.includes("cloudflare.com")) {
    browser.runtime.sendMessage({ ref: "r_click" }, handleCallback)
    // setTimeout(() => {
    // }, 1000);
    return true
  }
  return false
}

async function wait(s) {
  return new Promise((rs) => {
    setTimeout(() => {
      rs()
    }, s * 1000)
  })
}
